package uk.ac.ed.inf.powergrab;

import java.util.*;

//hold the positive and negative stations that have been separated from all the powerstations
class SeparateStations {

	ArrayList<Powerstation> positive = new ArrayList<Powerstation>();
	ArrayList<Powerstation> negative = new ArrayList<Powerstation>();
	
}
