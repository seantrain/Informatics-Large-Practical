package uk.ac.ed.inf.powergrab;
//custom data structure to store values for the closest powerstation
class ClosestStation {
	//holds the index value of the closest powerstation
	int index;
	//holds the coins and power of the closest powerstation
	double totalcoins;
	double totalpower;
}
