package uk.ac.ed.inf.powergrab;

import java.util.*;
//holds the set of directions, set of positions, new position and the status of the station (skipped)
class DronesMoves {

	ArrayList<Position> positionset = new ArrayList<Position>();
	Position updatedpos;
	boolean skip;
	double power;
	int moves;
	ArrayList<Double> powerholder = new ArrayList<Double>();
	ArrayList<Double> coinholder = new ArrayList<Double>();
	
}
